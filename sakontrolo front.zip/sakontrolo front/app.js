fetch('http://localhost:3000/films')
  .then(res => res.json)
  .then(res => displayFilms(res))
  .catch(err => console.log(err))

  const displayFilms = (data) => {
    const wrapper = document.querySelector('.wrapper')
    data.forEach(film => {
        wrapper.innerHTML += `
        <div class="card">
            <img src="${film.title}" alt="">
            <h1>${film.director}</h1>
            <h1>${film.year}</h1>
            <p>${film.genre}</p>
            <p>${film.rating}</p>
        </div> `
    });
}
const addFilm = () => {
    const title = document.getElementById('title').value
    const director = document.getElementById('director').value
    const year = document.getElementById('year').value
    const genre = document.getElementById('genre').value
    const rating = document.getElementById('rating').value

    const body = {
        title, director,  year, genre, rating
    }
       fetch('http://localhost:3000/films', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
    })
        .then(res => res.json())
        .then( res => location.reload())
        .catch(err => console.log(err))
}
 
const getallfilms = () => {
    fetch('http://localhost:5000/api/films')
        .then(res => res.json())
        .then(data => {
            displayFilms(data);
        })
        .catch(err => console.log('Error films', err))
}
 
const deletefilms = () => {
    fetch('http://localhost:5000/api/films'),{
        method :'delete',
    }
    .then(res => res.json())
    .then(data => {
         console.log('film deleted')
    } )
    .catch(err => console.log('error'))
    
}
const putfilms = () =>{
     fetch('http://localhost:5000/api/films'),{
        method :'put',
    }
    .then(res => res.json())
    .then(data => console.log(data))
    .catch(err => console.log('error'))
}




 
